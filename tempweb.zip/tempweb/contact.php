<?php include 'head.php'; 





?>
      
      
     


      


       


       


        <!-- Property List Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Contact</h1>
                            <!-- <p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit diam justo sed rebum.</p> -->
                        </div>
                    </div>
                    
                </div>

                
                
                <div class="col-lg-12">
                    <div class="contact-info bg-light p-4 rounded text-center">
                        <h4 class="mb-3">Get In Touch</h4>
                        <p class="mb-0">DELIGHT DISTRIBUTION INC. <br>
                        <span class="d-block">5605, 55th DRIVE</span>
                        <span class="d-block">MASPETH, NEW YORK 11378, USA.</span>
                        </p>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="contact-info bg-light p-4 rounded text-center">
                        <h4 class="mb-3">Contact Us</h4>
                        <p class="mb-0">
                            <span class="d-block">Mobile: </span>
                            <a href="tel:+19173885447">(+1) 917 388 5447</a>  , <a href="tel:+8801733390301">(+88) 0173 339 0301</a><br>
                            <span class="d-block">Email: </span>
                            <a href="mailto:director@ovijatfood.com">director@ovijatfood.com</a>
                        </p>
                    </div>
                </div>




            </div>
        </div>
        <!-- Property List End -->


       


        


       
        

 <?php include 'foot.php'; ?>