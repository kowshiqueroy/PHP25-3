<?php


if ( $_SESSION['role'] !== 0 ) {
    header("Location: ../manager/");

}

?>




hello admin